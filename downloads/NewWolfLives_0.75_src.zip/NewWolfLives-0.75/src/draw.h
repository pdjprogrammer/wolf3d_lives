/*

	Drawing Functions
www.partymix.lv - cool music!!!!!
*/



#include "sprt_def.h"

