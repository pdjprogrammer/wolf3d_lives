// ai common functions

void T_Stand(Guard_struct *self);
void T_Path(Guard_struct *self);
void T_Ghosts(Guard_struct *self);
void T_Chase(Guard_struct *self);
void T_Bite(Guard_struct *self);
void T_DogChase(Guard_struct *self);
void T_BossChase(Guard_struct *self);
void T_Fake(Guard_struct *self);

void T_Shoot(Guard_struct *self);
void T_UShoot(Guard_struct *self);
void T_Launch(Guard_struct *self);
