void Text_DisplayPage(void);
void Text_NewArticle(char *src, int size);
int Text_Input(int key);
