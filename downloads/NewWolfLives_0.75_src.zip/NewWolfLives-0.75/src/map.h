extern bool Map_CheckLine(int x1, int y1, int x2, int y2);
